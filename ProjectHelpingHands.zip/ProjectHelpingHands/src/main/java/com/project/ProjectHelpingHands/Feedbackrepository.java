package com.project.ProjectHelpingHands;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Feedbackrepository extends JpaRepository<Feedback, Long>
{
}
