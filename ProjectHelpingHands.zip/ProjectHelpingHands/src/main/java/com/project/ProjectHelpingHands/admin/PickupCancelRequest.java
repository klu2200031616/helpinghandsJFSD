package com.project.ProjectHelpingHands.admin;

public class PickupCancelRequest {
	 private Long pickupId;

	    public Long getPickupId() {
	        return pickupId;
	    }

	    public void setPickupId(Long pickupId) {
	        this.pickupId = pickupId;
	    }
}
