package com.project.ProjectHelpingHands;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectHelpingHandsApplicationTests {

	@Test
	void contextLoads() {
	}

}
